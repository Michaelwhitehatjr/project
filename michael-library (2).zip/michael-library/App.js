import React, { Component } from 'react';
import { Button, View, Text } from 'react-native';
import Transaction from './screens/transaction'
import Search from './screens/search'
import Login from './screens/login'
export default class App extends Component {
  constructor() {
    super();
  }
  render() {
    return (
        <Login />
    );
  }
}
