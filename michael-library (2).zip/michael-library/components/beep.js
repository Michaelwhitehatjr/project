import React, { Component } from 'react';
import {Button} from 'react-native';
import { Audio } from 'expo-av';

export default class Beep extends Component {
  constructor() {
    super();
    this.state = {
      colors: 'red',
    };
  }
  changeColor = async () => {
    this.props.navigation.navigate("SecondScreen");
    // const { sound } = await Audio.Sound.createAsync(require('./voice.mp3'));
    // await sound.playAsync();

    // this.setState({
    //   colors:
    //     'rgb(' +
    //     Math.floor(Math.random() * 256) +
    //     ',' +
    //     Math.floor(Math.random() * 256) +
    //     ',' +
    //     Math.floor(Math.random() * 256) +
    //     ')',
    // });
    alert('trans people are valid');
  };
  render() {
    return (
      <Button
        onPress={this.changeColor}
        color={this.state.colors}
        title="panda"></Button>
    );
  }
}
