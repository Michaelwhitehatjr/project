import * as firebase from 'firebase';
require('@firebase/firestore');
var firebaseConfig = {
  apiKey: 'AIzaSyDwT7tqNp3PjSQdsT0y2wfYyMptgx-BtTw',
  authDomain: 'scan-86ce5.firebaseapp.com',
  projectId: 'scan-86ce5',
  storageBucket: 'scan-86ce5.appspot.com',
  messagingSenderId: '51319040292',
  appId: '1:51319040292:web:1c3a61d65154d54bb2ebb1',
};
firebase.initializeApp(firebaseConfig);

export default firebase.firestore();
