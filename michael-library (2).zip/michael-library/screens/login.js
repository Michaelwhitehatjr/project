import React, { Component } from 'react';
import {
  Text,
  FlatList,
  TouchableOpacity,
  View,
  TextInput,
  Button,
} from 'react-native';
import db from '../config';
import firebase from 'firebase'
export default class Login extends Component {
  constructor() {
    super();
    this.state = {
      email: '',
      password: '',
    };
  }
  render() {
    return (
      <View>
        <TextInput
          onChangeText={(typedword) => {
            this.setState({ email: typedword });
          }}
          placeholder="Email"
          style={{ border: 3, borderStyle: 'solid' }}
        />
        <TextInput
        secureTextEntry
          onChangeText={(typedword) => {
            this.setState({ password: typedword });
          }}
          placeholder="Password"
          style={{ border: 3, borderStyle: 'solid', marginVertical: 5 }}
        />
        <TouchableOpacity
          onPress={() => {
            firebase
              .auth()
              .signInWithEmailAndPassword(this.state.email, this.state.password)
              .then((userCredential) => {
                alert("Signed in!")
              })
              .catch((error) => {
                var errorCode = error.code;
                var errorMessage = error.message;
              });
          }}
          style={{
            backgroundColor: 'turquoise',
            width: '75%',
            alignSelf: 'center',
            borderRadius: 20,
          }}>
          <Text style={{ fontSize: 18, textAlign: 'center' }}>Login</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => {
            firebase
              .auth()
              .createUserWithEmailAndPassword(this.state.email, this.state.password)
              .then((userCredential) => {
                alert("Signed up!")
              })
              .catch((error) => {
                var errorCode = error.code;
                var errorMessage = error.message;
              });
          }}
          style={{
            backgroundColor: 'turquoise',
            width: '75%',
            alignSelf: 'center',
            borderRadius: 20,
          }}>
          <Text style={{ fontSize: 18, textAlign: 'center' }}>Sign Up</Text>
        </TouchableOpacity>
      </View>
    );
  }
}
