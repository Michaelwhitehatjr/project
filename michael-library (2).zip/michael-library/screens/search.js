import React, { Component } from 'react';
import {
  Text,
  FlatList,
  TouchableOpacity,
  View,
  TextInput,
  Button
} from 'react-native';
import db from '../config';
export default class Search extends Component {
  constructor() {
    super();
    this.state = {
      requests: [],
      mainRequests:[],
      searchword: '',
    };
  }
  componentDidMount() {
    var temp = [];
    db.collection('request')
      .get()
      .then((snapshot) => {
        snapshot.forEach((doc) => {
          temp.push(doc.data());
        });
        this.setState({ requests: temp,mainRequests:temp });
        console.log(this.state.requests);
      });
  }

  search() {
    console.log(this.state.searchword)
    if (this.state.searchword === '') {
      console.log("Empty")
      this.setState({requests:this.state.mainRequests})
    } else {
      var temp=[]
      for (var r of this.state.requests) {
      console.log(r)
        if(r.bookID.includes(this.state.searchword) ||r.studentID.includes(this.state.searchword)){
            temp.push(r)
        }
      }
      this.setState({requests:temp})
    }
  }
  render() {
    return (
      <View>
        <TextInput
          onChangeText={(typedword) => {
            this.setState({ searchword: typedword });
          }}
          placeholder="Search"
          style={{ border: 3, borderStyle: 'solid' }}
        />
        <Button title="search" onPress={()=>this.search()} />
      <FlatList
          data={this.state.requests}
          renderItem={({ item, index, separators }) => (
            <TouchableOpacity
              key={item.key}
              onPress={() => this._onPress(item)}
              onShowUnderlay={separators.highlight}
              onHideUnderlay={separators.unhighlight}>
              <View
                style={{
                  backgroundColor: 'turquoise',
                  marginBottom: 15,
                  marginTop: 15,
                  borderRadius: 11,
                }}>
                <Text
                  style={{ fontWeight: 'bold', fontSize: 15, marginLeft: 10 }}>
                  Book ID: {item.bookID}
                </Text>
                <Text
                  style={{ fontStyle: 'italic', fontSize: 15, marginLeft: 10 }}>
                  Student ID: {item.studentID}
                </Text>
              </View>
            </TouchableOpacity>
          )}
        />
      </View>
    );
  }
}
