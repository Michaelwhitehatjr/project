import React, { Component } from 'react';
import {
  Button,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import * as Permissions from 'expo-permissions';
import { BarCodeScanner } from 'expo-barcode-scanner';
import db from '../config';
export default class Transaction extends Component {
  constructor() {
    super();
    this.state = {
      hasCameraPermissions: null,
      scanned: false,
      scannedData: '',
      bookID: '',
      studentID: '',
      buttonState: 'normal',
      available: true,
    };
  }
  requestBook = async () => {
    var bookref = await db
      .collection('books')
      .doc(this.state.bookID)
      .get()
      .then((data) => {
        var bookdata = data.data();

        if (bookdata.available) {
          db.collection('students')
            .doc(this.state.studentID)
            .get()
            .then((stud) => {
              var studdata = stud.data();
              console.log(studdata);
              if (studdata && studdata.numberofbooks<2) {
                db.collection('request').add({
                  bookID: this.state.bookID,
                  studentID: this.state.studentID,
                  status: 'Issued',
                });

                db.collection("books").doc(this.state.bookID).update({
                  available:false
                })

                db.collection("students").doc(this.state.studentID).update({
                  numberofbooks: studdata.numberofbooks+1
                })

                alert('Book issued');
              }
            });
        } else {
          alert('Book is not available');
        }
      });
  };
  getCameraPermissions = async (bs) => {
    const { status } = await Permissions.askAsync(Permissions.CAMERA);

    this.setState({
      /*status === "granted" is true when user has granted permission
          status === "granted" is false when user has not granted the permission
        */
      hasCameraPermissions: status === 'granted',
      buttonState: bs,
      scanned: false,
    });
  };

  handleBarCodeScanned = async ({ type, data }) => {
    if (this.state.buttonState === 'book') {
      this.setState({
        scanned: true,
        bookID: data,
        buttonState: 'normal',
      });
    }
    if (this.state.buttonState === 'student') {
      this.setState({
        scanned: true,
        studentID: data,
        buttonState: 'normal',
      });
    }
  };

  render() {
    const hasCameraPermissions = this.state.hasCameraPermissions;
    const scanned = this.state.scanned;
    const buttonState = this.state.buttonState;

    if (buttonState !== 'normal' && hasCameraPermissions) {
      return (
        <BarCodeScanner
          onBarCodeScanned={scanned ? undefined : this.handleBarCodeScanned}
          style={StyleSheet.absoluteFillObject}
        />
      );
    } else if (buttonState === 'normal') {
      return (
        <View style={styles.container}>
          <Text> Michael's Library </Text>
          <TextInput
            onChangeText={(typed) => {
              this.setState({ bookID: typed });
            }}
            value={this.state.bookID}
            placeholder="Book ID"
            style={{ border: 3, borderStyle: 'solid' }}
          />

          <TouchableOpacity
            onPress={() => {
              this.getCameraPermissions('book');
            }}
            style={styles.scanButton}>
            <Text style={styles.buttonText}>Scan Book ID</Text>
          </TouchableOpacity>

          <TextInput
            onChangeText={(typed) => {
              this.setState({ studentID: typed });
            }}
            value={this.state.studentID}
            placeholder="Student ID"
            style={{ border: 3, borderStyle: 'solid' }}
          />

          <TouchableOpacity
            onPress={() => {
              this.getCameraPermissions('student');
            }}
            style={styles.scanButton}>
            <Text style={styles.buttonText}>Scan Student ID</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              this.requestBook();
            }}
            style={{
              backgroundColor: 'black',
              borderRadius: 20,
              width: '75%',
            }}>
            <Text
              style={{ color: '#FF003D', fontSize: 25, textAlign: 'center' }}>
              Request
            </Text>
          </TouchableOpacity>
        </View>
      );
    }
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#7CB9E8',
  },
  displayText: {
    fontSize: 15,
    textDecorationLine: 'underline',
  },
  scanButton: {
    backgroundColor: '#FF003D',
    margin: 10,
  },
  buttonText: {
    fontSize: 20,
  },
});
